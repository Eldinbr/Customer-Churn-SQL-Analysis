# Screenshots

Add PostgreSQL query-result screenshots here as the project develops.

Suggested screenshots:
- schema_overview.png
- churn_by_contract.png
- overall_churn_query.png
- revenue_at_risk_query.png
- high_risk_customers.png
