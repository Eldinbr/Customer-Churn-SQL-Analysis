# Project Title: **Customer-Churn-SQL-Analysis**

A SQL-based Customer Churn Analysis project built using PostgreSQL. This project analyzes customer churn, contract types, customer tenure, service usage, monthly charges, payment methods, and customer value to identify patterns that can support data-driven customer retention strategies.

The project demonstrates practical SQL skills including data exploration, data quality checks, aggregations, CTEs, conditional logic, window functions, ranking, segmentation, and business-focused analysis.

## Preview

### SQL Analysis

The project contains a collection of SQL queries covering customer churn, revenue at risk, customer segmentation, contract performance, and advanced risk analysis.

---

## Table of Contents

- [Overview](#overview)
- [Dataset](#dataset)
- [Database Schema](#database-schema)
- [Technologies Used](#technologies-used)
- [Installation](#installation)
- [Usage](#usage)
- [Analysis & SQL Queries](#analysis--sql-queries)
- [Key Insights](#key-insights)
- [Business Value](#business-value)
- [Conclusion](#conclusion)
- [Credits](#credits)
- [License](#license)

---

## Overview

- **Motivation:** Customer churn is a major challenge for subscription-based businesses. Understanding which customer groups are most likely to leave can help organizations improve retention and protect recurring revenue.
- **Objective:** The main objective of this project is to analyze customer churn using PostgreSQL and identify customer, contract, service, and pricing factors associated with higher churn.
- **Learning Outcomes:** While building this project, I developed and applied SQL skills including data exploration, data-quality checks, aggregations, CTEs, CASE statements, window functions, ranking, customer segmentation, revenue analysis, and risk scoring.

---

## Dataset

### Dataset Information

- **Dataset Type:** Customer Churn Dataset
- **Records:** 5,000 customers
- **Features:** Customer demographics, tenure, contract, services, charges, payment method and churn

### Features Included

- Customer ID
- Gender
- Senior Citizen
- Partner
- Dependents
- City
- Tenure
- Contract Type
- Internet Service
- Technical Support
- Paperless Billing
- Payment Method
- Monthly Charges
- Total Charges
- Churn

### Data Preparation

The dataset was prepared and structured for PostgreSQL analysis:

- Duplicate detection
- Missing-value checks
- Invalid-value checks
- Churn validation
- Customer segmentation
- Churn-rate calculations
- Revenue-at-risk calculations
- Customer risk scoring

---

## Database Schema

The project contains one primary customer table designed for analytical SQL practice.

```text
Customers
│
├── Customer Information
│   ├── customer_id
│   ├── gender
│   ├── senior_citizen
│   ├── partner
│   └── dependents
│
├── Subscription Information
│   ├── tenure_months
│   ├── contract
│   ├── internet_service
│   └── tech_support
│
└── Financial Information
    ├── monthly_charges
    ├── total_charges
    └── churn
```

---

## Technologies Used

- **Database:** PostgreSQL
- **Language:** SQL
- **Tools & Platforms:** PostgreSQL, Git, GitHub
- **Skills Applied:** Data Cleaning, Data Exploration, Data Analysis, Customer Analytics, Business Intelligence

### SQL Concepts Used

- SELECT
- WHERE
- ORDER BY
- GROUP BY
- HAVING
- Aggregate Functions
- CASE WHEN
- CTEs
- Window Functions
- RANK
- DENSE_RANK
- Conditional Aggregation
- Subqueries
- Customer Segmentation
- Risk Scoring

---

## Installation

To explore this project locally:

```bash
# Clone the repository
git clone https://github.com/eldinbr/Customer-Churn-SQL-Analysis.git

# Navigate into the project directory
cd Customer-Churn-SQL-Analysis
```

### Database Setup

1. Create a PostgreSQL database.
2. Run `sql/00_schema.sql`.
3. Import `data/customers.csv`.
4. Execute the SQL scripts in numerical order.

---

## Usage

Instructions for using the project:

1. Download or clone the repository.
2. Create a PostgreSQL database.
3. Create the table using `00_schema.sql`.
4. Import the customer dataset.
5. Run the SQL queries.
6. Review the results and document the business insights.

The project allows users to:

- Calculate overall churn rate
- Compare churn across contract types
- Analyze churn by customer tenure
- Analyze churn by internet service
- Compare churn by payment method
- Identify high-value customers
- Calculate monthly recurring revenue
- Calculate revenue at risk
- Rank cities by churn rate
- Identify high-risk customers
- Create customer risk segments

---

## Analysis & SQL Queries

### 1. Data Exploration

The initial analysis explores the customer dataset.

Examples include:

- Total customer count
- Churn distribution
- Customers by contract
- Customers by internet service
- Average monthly charges

### 2. Churn Analysis

The churn analysis focuses on identifying customer groups with higher churn.

Key questions include:

- What is the overall churn rate?
- Which contract has the highest churn?
- Which internet service has the highest churn?
- Does customer tenure affect churn?
- Which payment methods have higher churn?

Example:

```sql
SELECT
    contract,
    COUNT(*) AS customers,
    COUNT(*) FILTER (WHERE churn='Yes') AS churned_customers,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE churn='Yes') / COUNT(*),
        2
    ) AS churn_rate_pct
FROM customers
GROUP BY contract
ORDER BY churn_rate_pct DESC;
```

### 3. Customer Segmentation

Customers are segmented based on value, tenure and service characteristics.

Key questions include:

- Which customer value segment has the highest churn?
- Are senior customers more likely to churn?
- Does technical support affect churn?
- How does paperless billing relate to churn?

### 4. Revenue Analysis

The project evaluates the financial impact of churn.

Key metrics include:

- Monthly recurring revenue
- Monthly revenue at risk
- Historical revenue from churned customers
- Average monthly charges
- Average customer value
- Revenue by contract type

### 5. Advanced SQL Analysis

Advanced SQL techniques are used to identify higher-risk customer groups.

#### Contract Churn Ranking

`RANK()` is used to rank contracts by churn rate.

#### City Churn Ranking

`DENSE_RANK()` identifies cities with the highest churn rates.

#### Customer Risk Score

A custom SQL score combines:

- Contract type
- Tenure
- Monthly charges
- Technical support
- Paperless billing

Customers are classified into:

- High Risk
- Medium Risk
- Low Risk

---

## Key Insights

The analysis is designed to identify:

- Customer groups with the highest churn
- Contract types associated with higher churn
- The relationship between tenure and churn
- Service-related churn patterns
- High-value customers at risk
- Revenue exposed to customer churn
- Locations with higher churn rates
- Customer characteristics associated with increased churn risk

---

## Business Value

The analysis can support:

- **Customer Retention:** Identify customers most likely to leave.
- **Revenue Protection:** Quantify monthly recurring revenue at risk.
- **Customer Segmentation:** Group customers according to value and risk.
- **Contract Strategy:** Understand churn differences between contract types.
- **Service Strategy:** Evaluate service-related retention patterns.
- **Marketing:** Create targeted retention campaigns.
- **Customer Experience:** Identify customer groups requiring additional engagement.

---

## Conclusion

The Customer Churn SQL Analysis project demonstrates how SQL can be used to transform customer-level data into actionable business insights.

Through PostgreSQL and advanced SQL techniques, the project analyzes churn behavior, customer value, contract performance, service usage, and revenue risk.

The project demonstrates a practical Data Analyst workflow:

**Raw Data → Data Quality → SQL Analysis → Customer Segmentation → Business Insights → Recommendations**

### Recommendations

- Prioritize retention campaigns for high-risk month-to-month customers.
- Improve onboarding for customers during their first year.
- Investigate high monthly charges among customers who churn.
- Promote technical support and proactive customer service.
- Monitor high-value customers who show signs of churn risk.
- Regularly track churn by contract, service and payment method.

---

## Credits

- **Developer:** Eldin B. Joseph
- **Dataset:** Customer Churn Dataset
- **Database:** PostgreSQL
- **Analysis Tool:** SQL
- **Version Control:** GitHub

---

## License

This project is licensed under the **MIT License** – feel free to use and modify it.

---

**Thanks for visiting! 🚀**
